
#include "Logger.h"

using namespace Utilities::Logger;

void execute(int, double)
{
    log(log_level::Error, "Error in execute!");
}

int main()
{
    log(log_level::Info, "Logging from main!");
    execute(0, 0);

    return 0;
}