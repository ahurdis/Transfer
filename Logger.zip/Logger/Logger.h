#include <chrono>
#include <filesystem>
#include <format>
#include <iostream>
#include <source_location>
#include <string>

namespace Utilities::Logger
{
    enum class log_level : char
    {
        Info = 'I',
        Warning = 'W',
        Error = 'E'
    };

    namespace inner
    {

        auto as_local(std::chrono::system_clock::time_point const tp)
        {
            return std::chrono::zoned_time{std::chrono::current_zone(), tp};
        }

        void foo() {}

        std::string to_string(auto tp)
        {
            return std::format("{:%F %T %Z}", tp);
        }

        std::string to_string(std::source_location const source)
        {
            return std::format("{}:{}:{}",
                               std::filesystem::path(source.file_name()).filename().string(),
                               source.function_name(),
                               source.line());
        }

    }

    void log(log_level const level,
             std::string_view const message,
             std::source_location const source = std::source_location::current())
    {
        std::cout << std::format("[{}] {} | {} | {}",
                                 static_cast<char>(level),
                                 inner::to_string(inner::as_local(std::chrono::system_clock::now())),
                                 inner::to_string(source),
                                 message)
                  << '\n';

        if (level == log_level::Error)
        {
            exit(1);
        }
    }
};
