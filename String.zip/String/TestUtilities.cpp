/*
 * 
*/

#include <iostream>
#include <string>
#include <vector>

#include "StringUtilities.h"

using namespace std;

//------------------------------------------------------------------------------
// Name: starts_with
//------------------------------------------------------------------------------

template <typename container, typename type>
inline bool starts_with(const container &ct, type t)
{
    return !ct.empty() && ct.front() == t;
}


int main()
{
    string s = "foobar, chewie, monkey,  ,";

    cout << Utilities::String::rtrim_punctionation(s) << " and then the rest" << '\n';;

//    starts_with<string, char>("foobar", 'b');

    cout << "foobar starts with b? " << starts_with<string, char>("foobar", 'b') << '\n';;

    vector<string> v{"monkey", "banana", "tree"};


    string sMonkey = "monkey";

    cout << "Array starts with monkey? " << starts_with<vector<string>, string>(v, sMonkey) << '\n';;

    cout << Utilities::String::capitalize(sMonkey) << '\n';

    return 0;
}