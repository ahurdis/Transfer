#pragma once

#include <charconv>
#include <string_view>
#include <stdexcept>
#include <optional>
#include <type_traits>

namespace Utilities::String
{
    using throw_on_error = std::false_type;
    using return_error_code = std::negation<throw_on_error>;

    template <typename T, typename ERROR_METHOD = throw_on_error>
    [[nodiscard]] inline constexpr T lexic_cast(std::string_view sv,
                                                const char **next = nullptr,
                                                const std::optional<T> error_code = {T{} - 1}) noexcept(ERROR_METHOD::value)
    {
        if constexpr (!ERROR_METHOD::value)
        {
            sv.remove_prefix(sv.find_first_not_of("+ "));
        }

        T var{error_code.value_or(T{} - 1)};

        auto [ptr, ec] {std::from_chars(sv.data(), sv.data() + sv.size(), var)};

        if (next)
        {
            *next = ptr;
        }

        if constexpr (!ERROR_METHOD::value)
        {
            if (error_code != (T{} - 1))
            {
                return var;
            }
            if (ec != std::errc{})
            {
                throw std::runtime_error{"Parsing error!"};
            }
        }
        return var;
    }
}