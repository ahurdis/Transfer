#pragma once

#include <memory>

#include "Layer.h"
#include "..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;

class FlattenLayer : public Layer
{
public:
    FlattenLayer(const std::pair<size_t, size_t> shape)
        : _shape(shape)
    {

    }

    Matrix<double> &forwardPropagation(const Matrix<double> &inputData) override
    {
        _reshapeInput = Matrix<double>::createReshape(inputData, 1, 0);

    //    std::cout << "flatten forward shape " << _reshapeInput.describeShape();
    //    std::cout << "flatten forward " << _reshapeInput;

        return _reshapeInput;
    }

    Matrix<double> backwardPropagation(const Matrix<double> &outputError, [[maybe_unused]]const double learningRate) override
    {
        return Matrix<double>::createReshape(outputError, _shape.first, _shape.second);
    }

private:

    Matrix<double> _reshapeInput;

    std::pair<size_t, size_t> _shape;
};