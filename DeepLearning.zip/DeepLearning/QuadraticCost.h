
#pragma once

#include "CostFunction.h"
#include "..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;

class QuadraticCost : public CostFunction
{
    // CostFunction interface
public:
    Matrix<double> delta(const Matrix<double> &z_weightdInput, const Matrix<double> &a_activation,
                                        const Matrix<double> &y_expected) const
    {
        return ((a_activation - y_expected).array() * Neuron::d_sigmoid(z_weightdInput).array()).matrix();
    }

    double cost(const Matrix<double> &a_activation, const Matrix<double> &y_expected) const
    {
        Matrix<double> sqn = (a_activation - y_expected).colwise().squaredNorm();
        return 0.5 * sqn.sum() / double(sqn.cols());
        ;
    }

    std::string name() const override { return "quadraticcost"; }
};
