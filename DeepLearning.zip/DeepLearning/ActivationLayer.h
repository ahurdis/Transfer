#pragma once

#include <functional>
#include <memory>

#include "Layer.h"
#include "..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;

class ActivationLayer : public Layer
{
public:
    ActivationLayer(const std::function<Matrix<double>(Matrix<double> &)> activationFunction,
                    const std::function<Matrix<double>(Matrix<double> &)> activationFunctionPrime)
        : _activationFunction(activationFunction),
          _activationFunctionPrime(activationFunctionPrime)
    {
    }

    Matrix<double> &forwardPropagation(const Matrix<double> &inputData) override
    {
        _input = inputData;

        _output = _activationFunction(_input);

    //    std::cout << "flatten forward shape " << _output.describeShape();
    //    std::cout << "flatten forward " << _output;

        return _output;
    }

    Matrix<double> backwardPropagation(const Matrix<double> &outputError, [[maybe_unused]] const double learningRate) override
    {
        return outputError.dotBroadcast(_activationFunctionPrime(_input));
    }

private:
    std::function<Matrix<double>(Matrix<double> &)> _activationFunction;
    std::function<Matrix<double>(Matrix<double> &)> _activationFunctionPrime;
};