#include <format>
#include <iostream>
#include <memory>

#include "Network.h"
#include "ActivationLayer.h"
#include "FullyConnectedLayer.h"

auto msePrime = [](const Matrix<double> &y_true, const Matrix<double> &y_pred)
{
    return ((y_pred - y_true) * (2.0 / (double)(y_pred.size())));
};

auto mse = [](const Matrix<double> &y_true, const Matrix<double> &y_pred)
{
    return ((y_true - y_pred) ^ 2.0).mean();
};

auto actTanhPrime = [](const Matrix<double> &x)
{
    return (1.0 - (x.tanh() ^ 2.0));
};

auto actTanh = [](const Matrix<double> &x)
{
    return x.tanh();
};

auto main() -> int
{
    // xor
    const std::vector<Matrix<double>> x_train{{{0, 0}}, {{0, 1}}, {{1, 0}}, {{1, 1}}};
    const std::vector<Matrix<double>> y_train{{{0}}, {{1}}, {{1}}, {{0}}};

    std::unique_ptr<Network> network = std::make_unique<Network>();

    network->addLayer(std::move(std::make_shared<FullyConnectedLayer>(2, 3)));
    network->addLayer(std::move(std::make_shared<ActivationLayer>(actTanh, actTanhPrime)));
    network->addLayer(std::move(std::make_shared<FullyConnectedLayer>(3, 1)));
    network->addLayer(std::move(std::make_shared<ActivationLayer>(actTanh, actTanhPrime)));

    network->use(mse, msePrime);

    network->fit(x_train, y_train, 1000, 0.1);

    std::vector<Matrix<double>> results = network->predict(x_train);

    std::cout << "\n***** Predict ********\n\n";

    for (size_t i = 0; i < x_train.size(); ++i)
    {
        std::cout << "Input \n"
                  << x_train[i];
        std::cout << "Output \n"
                  << results[i] << "\n";
    }
}