#pragma once

#include "..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;

class Layer
{
public:

    /**
     * @brief Performs the forward propagation step for the layer.
     *
     * @param inputData The input data for the layer.
     * @return Matrix<double>& A reference to the output of the layer.
     */
    virtual Matrix<double> &forwardPropagation([[maybe_unused]] const Matrix<double> &inputData) = 0;

    /**
     * @brief Performs the backward propagation step for the layer.
     *
     * @param outputError The error at the output of the layer.
     * @param learningRate The learning rate for the network.
     * @return Matrix<double> The error at the input of the layer.
     */
    virtual Matrix<double> backwardPropagation([[maybe_unused]] const Matrix<double> &outputError,
                                               [[maybe_unused]] const double learningRate) = 0;

protected:
    Matrix<double> _input;
    Matrix<double> _output;
};