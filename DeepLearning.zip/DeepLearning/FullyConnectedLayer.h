#pragma once

#include <memory>

#include "Layer.h"
#include "..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;

class FullyConnectedLayer : public Layer
{
public:
    FullyConnectedLayer(const size_t inputSize, const size_t outputSize)
        : _weights(inputSize, outputSize),
          _bias(1, outputSize)
    {

        //_weights.toZeros();

        _weights.fill(0.1);
        _bias.fill(-0.1);

       // _weights.toRandomValues() /= std::sqrt(inputSize + outputSize);
       // _bias.toRandomValues() /= std::sqrt(inputSize + outputSize);
    }

    Matrix<double> &forwardPropagation(const Matrix<double> &inputData) override
    {
        _input = inputData;
        _output = (_input * _weights) + _bias;
        //    std::cout << "FC forward shape " << _output.describeShape();
        //    std::cout << "FC forward " << _output;
        return _output;
    }

    Matrix<double> backwardPropagation(const Matrix<double> &outputError, const double learningRate) override
    {
        //std::cout << "OutputError " << outputError;
        //exit(0);

        // Matrix<double> inputError = outputError * _weights.transpose();

        Matrix<double> inputError = outputError * _weights.transpose();

        std::cout << "inputError " << inputError;
        exit(0);


  //      std::cout << "_weights.t shape " << _weights.transpose().describeShape();
  //      std::cout << "_weights.t " << _weights.transpose();

        auto weightsError = _input.transpose() * outputError;

        _weights -= learningRate * weightsError;
        _bias -= learningRate * outputError;

        std::cout << "InputError " << inputError;
        exit(0);

        return inputError;
    }

private:
    Matrix<double> _weights;
    Matrix<double> _bias;
};