#pragma once

#include <memory>

#include "Layer.h"
#include "..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;

class SoftmaxLayer : public Layer
{
public:
    SoftmaxLayer(size_t inputSize)
        : _inputSize(inputSize)
    {
    }

    Matrix<double> &forwardPropagation(const Matrix<double> &inputData) override
    {
        _input = inputData;

        Matrix<double> temp =  inputData.exp();
        _output = temp / temp.sum();  

        // std::cout << "softmax forward " << _output;  exit(0);

        return _output;
    }

    Matrix<double> backwardPropagation(const Matrix<double> &outputError, [[maybe_unused]]const double learningRate) override
    {
        Matrix<double> inputError = Matrix<double>::createZeros(outputError.rows(), outputError.cols());
        Matrix<double> out = _output.transpose().tile(1, _inputSize);
        
        
        Matrix<double> temp =  outputError.dotBroadcast(Matrix<double>::createIdentity(_inputSize) - out);

        // std::cout << _output.dotBroadcast(temp); exit(0);
        
        return _output.dotBroadcast(temp);
    }

private:
    size_t _inputSize;
};