#include <format>
#include <iostream>
#include <memory>

#include "Network.h"
#include "ActivationLayer.h"
#include "FlattenLayer.h"
#include "FullyConnectedLayer.h"
#include "SoftmaxLayer.h"

#include "../Data/Integration/DataSet.h"
using namespace Data::Integration;

auto mse = [](const Matrix<double> &y_true, const Matrix<double> &y_pred)
{
    return ((y_true - y_pred) ^ 2.0).mean();
};

auto msePrime = [](const Matrix<double> &y_true, const Matrix<double> &y_pred)
{
    return ((y_pred - y_true) * (2.0 / (double)(y_pred.size())));
};

auto actTanh = [](const Matrix<double> &x)
{
    return x.tanh();
};

auto actTanhPrime = [](const Matrix<double> &x)
{
    return (1.0 - (x.tanh() ^ 2.0));
};

auto actRelu = [](const Matrix<double> &x)
{
    return Matrix<double>::maximum(x, 0.0);
};

auto actReluPrime = [](const Matrix<double> &x)
{
    Matrix<double> ret{x.rows(), x.cols()};

    for (size_t row = 0; row < ret.rows(); ++row)
    {
        for (size_t col = 0; col < ret.cols(); ++col)
        {
            if (x.getValue(row, col) > 0.0)
            {
                ret.setValue(row, col, 1.0);
            }
            else
            {
                ret.setValue(row, col, 0.0);
            }
        }
    }

    return ret;
};

std::vector<Matrix<double>> normalizePixels(std::vector<Matrix<double>> &vm)
{
    for (auto &m : vm)
    {
        m /= 255.0;
    }
    return vm;
};

auto main() -> int
{
    // mnist

    std::cout << "Loading data from mnist_train." << '\n';

    DataSet ds("c:/dev/C++/C++ Learning/DeepLearning/mnist_train1000.csv", ',', false);

    std::cout << "Split." << '\n';

    auto [train_x, train_y, test_x, test_y] = ds.split(1.0, 1);
//    auto [train_x, train_y, test_x, test_y] = ds.splitAtRow(8, 1);

    std::cout << "Make Network." << '\n';
    std::unique_ptr<Network> network = std::make_unique<Network>();

    network->addLayer(std::move(std::make_shared<FlattenLayer>(std::make_pair(28, 28))));
    network->addLayer(std::move(std::make_shared<FullyConnectedLayer>(28 * 28, 128)));
    network->addLayer(std::move(std::make_shared<ActivationLayer>(actRelu, actReluPrime)));
    network->addLayer(std::move(std::make_shared<FullyConnectedLayer>(128, 10)));
    network->addLayer(std::move(std::make_shared<SoftmaxLayer>(10)));

    network->use(mse, msePrime);

    network->fit(train_x, train_y, 20, 0.1);

    std::vector<Matrix<double>> results = network->predict(train_x);
/*
    std::cout << "\n***** Predict ********\n\n";

    for (size_t i = 0; i < train_x.size(); ++i)
    {
        std::cout << "Input \n"
                  << train_x[i];
        std::cout << "Output \n"
                  << results[i] << "\n";
    }
*/
}