#pragma once

#include <functional>
#include <memory>
#include <ranges>
#include <string>
#include <vector>

#include "Layer.h"
#include "..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;

class Network
{

public:
    Network()
    {
        initalizeNetwork();
    }

    void initalizeNetwork()
    {
    }

    void addLayer(std::shared_ptr<Layer> &&layer)
    {
        _layers.emplace_back(layer);
    }

    std::vector<Matrix<double>> predict(const std::vector<Matrix<double>> &inputData)
    {
        std::vector<Matrix<double>> ret;

        for (auto output : inputData)
        {
            for (auto &layer : _layers)
            {
                output = layer->forwardPropagation(output);
            }
            ret.push_back(output);
        }

        return ret;
    }

    void use(const std::function<double(Matrix<double> &, Matrix<double> &)> &lossFunction,
             const std::function<Matrix<double>(Matrix<double> &, Matrix<double> &)> &lossFunctionPrime)
    {
        _lossFunction = lossFunction;
        _lossFunctionPrime = lossFunctionPrime;
    }

    void fit(const std::vector<Matrix<double>> &x_train,
             const std::vector<Matrix<double>> &y_train,
             const size_t epochs,
             const double learningRate)
    {

        double displayError{};

        for (size_t epoch = 0; epoch < epochs; ++epoch)
        {
            displayError = 0.0;

            for (size_t sample = 0; sample < x_train.size(); ++sample)
            {
                Matrix<double> output = x_train[sample];

//                std::cout << "output " << output;  
//                std::cout << output.describeShape(); exit(0);

                for (auto &layer_forward : _layers)
                {
                    output = layer_forward->forwardPropagation(output);
                }

//                std::cout << "output " << output;  exit(0);


                auto param = y_train[sample];

//                std::cout << "train " << param;

                displayError += _lossFunction(param, output);

                // backward propagation
                Matrix<double> outputError = _lossFunctionPrime(param, output);

                for (auto &layer_backward : std::views::reverse(_layers))
                {
                    outputError = layer_backward->backwardPropagation(outputError, learningRate);
                }
            }

            displayError /= (double)x_train.size();

            std::cout << x_train.size() << std::endl;

            std::cout << std::format("epoch {} {} error {}", epoch + 1, epochs, displayError) << '\n';
        }
    }

    size_t getNumberOfLayers() const
    {
        return _layers.size();
    }

private:
    std::vector<std::shared_ptr<Layer>> _layers;
    std::function<double(Matrix<double> &, Matrix<double> &)> _lossFunction;
    std::function<Matrix<double>(Matrix<double> &, Matrix<double> &)> _lossFunctionPrime;
};
