#include <iostream>
#include <numeric>
#include <vector>

template <typename T>
T mean(std::vector<T> Data)
{
    return std::accumulate(std::begin(Data), std::end(Data), 0.0) / Data.size();
}

template <typename T>
double std_deviation(std::vector<T> &Data)
{
    T m = mean(Data);
    double sq_sum = std::inner_product(Data.begin(), Data.end(), Data.begin(), 0.0);
    double stdev = std::sqrt(sq_sum / Data.size() - (double)(m * m));
    return stdev;
}

auto main() -> int
{

    std::vector<double> v{1.2, 3.4, 2.5, 1.3};
    std::cout << mean(v) << '\n';
    std::cout << std_deviation(v) << '\n';
}