#include <iostream>

#include "MovingAverage.h"

int main()
{
    std::cout << MovingAverage<double, 2>{}(4)(7)(2)(6) << '\n';
    // "5\n"

    // average of last 3 squares...
    MovingAverage<double, 12> ma;

    for (int i = 0; i < 10; ++i)
    {
        std::cout << (i * i) << ':' << ma(i * i) << ' ';
    }

    std::cout << '\n';

    return 0;
}