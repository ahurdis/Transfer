#include <source_location>
#include <complex>
#include <vector>
#include <any>

#include "Matrix.h"

using namespace Mathematics::Matrix;

int main()
{

/* tile

    Matrix<int> m = {{1, 2, 3},
                     {4, 5, 6}};


    std::cout << m.tile(500, 799) + 1;


/*

    Matrix<int> X = {{1, 2, 3, 4, 5, 6}};

    std::cout << X.reshape(3, 2);

    std::cout << X.reshape(2, 3);

    std::cout << X.reshape(6, 1);


    Matrix<int> Y = {{1}, {2}, {3}, {4}, {5}, {6}};

    // std::cout << Y.reshape(2, 3);

    Matrix<int> Z = Y.reshape(3, 2);

    std::cout << Z;

    std::cout << Z.reshape(6, 1);
*/

    /*

    Matrix<int> X = {{1, 2, 3},
                     {4, 5, 6}};

    Matrix<int> R = {{7, 8},
                     {9, 10},
                     {11, 12}};

    std::cout << X * R << '\n';

    */

    /*
    Matrix<double> x = {{0.5}};
    std::cout << x.tanh();
    Matrix<double> y = x.tanh() ^ 2;
    std::cout << y;

    std::cout << (1.0 - (x.tanh() ^ 2.0));
    */

    /*
    const std::vector<double> fires = {6.2, 9.5, 10.5, 7.7, 8.6, 34.1, 11, 6.9, 7.3, 15.1, 29.1, 2.2, 5.7, 2, 2.5, 4, 5.4, 2.2, 7.2,
                                       15.1, 16.5, 18.4, 36.2, 39.7, 18.5, 23.3, 12.2, 5.6, 21.8, 21.6, 9, 3.6, 5, 28.6, 17.4, 11.3, 3.4,
                                       11.9, 10.5, 10.7, 10.8, 4.8};

    const std::vector<double> theft = {29, 44, 36, 37, 53, 68, 75, 18, 31, 25, 34, 14, 11, 11, 22, 16, 27, 9, 29, 30, 40, 32, 41, 147,
                                       22, 29, 46, 23, 4, 31, 39, 15, 32, 27, 32, 34, 17, 46, 42, 43, 34, 19};

    const Matrix<double> p(fires);
    const Matrix<double> q(theft);
    */

    /*
        // multiply as vector<double>
        const std::vector<double> vp = {1,
                                        2};
        Matrix<double> p{vp};
        std::cout << p.rows() << ',' << p.cols() << '\n';

        const std::vector<double> vq = {1.1,
                                        2.1};
        Matrix<double> q{vq};
        std::cout << q.rows() << ',' << q.cols() << '\n';;

        Matrix<double> s = p.transpose() * q;

        std::cout << s;
    */

    // Test Rotation by 90 degrees of matrix
    /*
        Matrix<double> X = {{5, 5, -1},
                            {4, -9, 20},
                            {9, -18, -3}};

        Matrix<double> R = {{0, 0, 1},
                            {0, 1, 0},
                            {1, 0, 0}};

        std::cout << X << '\n';

        Matrix<double> Xt = X.transpose();

        std::cout << Xt << '\n';
        Matrix<double> A = Xt * R;

        std::cout << A << '\n';
    */
    // multiply as initialization list
    /*
        Matrix<double> p{{1},
                         {2}};

        std::cout << p.rows() << ',' << p.cols() << '\n';

        Matrix<double> q{{1.1, 2.2}};
        std::cout << q.rows() << ',' << q.cols() << '\n';
        ;

        Matrix<double> s = p * q;
    //    Matrix<double> s = p.transpose() * q;

        std::cout << s;
    */
    
    /*
        Matrix<double> r{3, 2};
        std::cout << r.toOnes() << '\n';
        Matrix<double> augmentedColumns{3, 2};
        augmentedColumns.fill(3);
    */

    //    augmentedColumns.setValue(-19, 4);


//        std::cout << r.insertColumns(2, augmentedColumns);
    
    /* Test initialization helpers*/
    
    /*
        Matrix<double> a{3, 3};
        std::cout << a.toIdentity() << '\n';
        std::cout << a.toZeros() << '\n';
        std::cout << a.toOnes() << '\n';
        std::cout << a.resize(12, 12).toRandomValues() << '\n';
    */

    /*


        Matrix<double> u = Matrix<double>{1, 5}.toOnes();
        std::cout << u << '\n';

        Matrix<double> t = u.transpose();
        std::cout << t << '\n';

        Matrix<double> I = Matrix<double>::createIdentity(3);
        std::cout << I << '\n';
    */

    /*
    const std::vector<double> fires = {6.2, 9.5, 10.5, 7.7, 8.6, 34.1, 11, 6.9, 7.3, 15.1, 29.1, 2.2, 5.7, 2, 2.5, 4, 5.4, 2.2, 7.2,
                                       15.1, 16.5, 18.4, 36.2, 39.7, 18.5, 23.3, 12.2, 5.6, 21.8, 21.6, 9, 3.6, 5, 28.6, 17.4, 11.3, 3.4,
                                       11.9, 10.5, 10.7, 10.8, 4.8};

    const std::vector<double> theft = {29, 44, 36, 37, 53, 68, 75, 18, 31, 25, 34, 14, 11, 11, 22, 16, 27, 9, 29, 30, 40, 32, 41, 147,
                                       22, 29, 46, 23, 4, 31, 39, 15, 32, 27, 32, 34, 17, 46, 42, 43, 34, 19};

    const Matrix<double> x{fires};
    const Matrix<double> y{theft};
    */

    /*
        Matrix<double> x = {{5, 5, -1, 7, 54},
                            {4, -9, 20, 12, -6},
                            {9, -18, -3, 1, 21},
                            {61, -8, -10, 3, 13},
                            {29, -28, -1, 4, 14}};

        Matrix<double> y = {{7, 5, -1, 7, 54},
                            {4, -9, 20, 12, -6},
                            {9, -18, -3, 1, 21},
                            {61, -8, -10, 3, 13},
                            {29, -28, -1, 4, 14}};

        double m = 12.0;

        std::cout << m * x * (y + x);
    */

    /*
        // Test : split()

        Matrix<double> o = {{7, 5, -1, 7, 54},
                            {4, -9, 20, 12, -6},
                            {9, -18, -3, 1, 21},
                            {61, -8, -10, 3, 13},
                            {29, -28, -1, 4, 14}};


        std::pair<Matrix<double>, Matrix<double>> myPair = o.splitAtColumn(4);

        Matrix<double> a = myPair.first;
        Matrix<double> b = myPair.second;


        std::cout << 'A' << '\n' << a << '\n';
        std::cout << 'B' << '\n' << b << '\n';
    */

    // Test : getColumn(), getLastColumn()

    /*


        Matrix<int> a = {{1, 2},
                         {3, 2}};

        std::cout << a << '\n';*

    */

    //  std::cout << 'C' << '\n' << c << '\n';

    /*
    // Test: splitByFilter()
    auto [a, b] = o.splitByFilter(1, 0.0);
    std::cout << 'A' << '\n' << a << '\n';
    std::cout << 'B' << '\n' << b << '\n';
    */

    /*
    // Test: splitRandomly()
    auto [a, b] = o.splitRowsRandomly(0.6);
    std::cout << 'A' << '\n' << a << '\n';
    std::cout << 'B' << '\n' << b << '\n';
    */

    /*
            using namespace std::complex_literals;

            Matrix<std::complex<double>> m4(3, 3);
            m4.fill(1123. + 221i);

            Matrix<std::complex<double>> m5(3, 3);
            m5 = m4 * m4;

            std::cout << m5;
    */
    return 0;
}