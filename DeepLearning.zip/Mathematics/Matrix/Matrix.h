#pragma once

#include <iomanip>
#include <iostream>
#include <format>
#include <functional>
#include <random>
#include <source_location>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "..\..\Utilities\Logger\Logger.h"

using namespace Utilities;

namespace Mathematics
{
    namespace Matrix
    {

        /**
         * @class Matrix
         * @brief A class representing a matrix of values of type T.
         *
         * This class provides methods for constructing, manipulating, and destroying
         * matrices of values of type T. It provides several constructors for creating
         * matrices from different types of data, as well as methods for setting and
         * getting individual matrix elements and filling the matrix with a single value.
         * It also provides a copy constructor and an assignment operator for creating
         * copies of matrices and performing matrix assignment.
         */

        template <typename T>
        class Matrix
        {

        private:
            /**
             * @brief Number of rows in the matrix.
             */

            size_t rows_;
            /**
             * @brief Number of columns in the matrix.
             */

            /**

 @brief 2D array of data for the matrix.
 */
            size_t cols_;
            T **p;

        public:
            /**
             * @brief Constructs a new matrix with a single element.
             */
            Matrix() : Matrix(1, 1)
            {
            }

            /**
             * @brief Constructs a new matrix with the specified number of rows and columns.
             *
             * @param rows The number of rows in the matrix.
             * @param cols The number of columns in the matrix.
             */
            Matrix(size_t rows, size_t cols) : rows_(rows), cols_(cols)
            {
                if (rows_ < 0)
                {
                    Logger::log(Logger::log_level::Error, "Rows out of bounds.");
                }
                if (cols_ < 0)
                {
                    Logger::log(Logger::log_level::Error, "Column out of bounds.");
                }

                allocSpace();
            }

            /**
             * @brief Constructs a new matrix with the specified values.
             *
             * @param t A 2D array of values to fill the matrix with.
             * @param rows The number of rows in the matrix.
             * @param cols The number of columns in the matrix.
             */
            Matrix(T **t, size_t rows, size_t cols) : Matrix(rows, cols)
            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        p[i][j] = t[i][j];
                    }
                }
            }
            
            /**
             * @brief Constructs a new matrix with the specified values using an initializer list.
             *
             * @param listlist An initializer list of initializer lists containing the values to fill the matrix with.
             */
            Matrix(std::initializer_list<std::initializer_list<T>> listlist)
                : Matrix(listlist.size(), (listlist.begin())->size())

            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    // p[i] = new T[cols_];
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        auto row = listlist.begin() + i;
                        p[i][j] = row->begin()[j];
                    }
                }
            }
            
            /**
             * @brief Constructs a new matrix with a single column and the specified number of rows, filled with the values from the vector.
             *
             * @param v A vector containing the values to fill the matrix with.
             */
            Matrix(const std::vector<T> &v) : Matrix(v.size(), 1)
            {
                size_t k{0};
                for (size_t i = 0; i < rows_; ++i)
                {
                    p[i][0] = v[k++];
                }
            }
            
            /**
             * @brief Destroys the matrix.
             */ 
            ~Matrix()
            {
                freeSpace();
            }
            
            /**
             * @brief Constructs a new matrix as a copy of an existing matrix.
             *
             * @param m The matrix to copy.
             */
            Matrix(const Matrix &m) : Matrix(m.rows_, m.cols_)
            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        p[i][j] = m.p[i][j];
                    }
                }
            }
            
            /**
             * @brief Assigns the values of an existing matrix to this matrix.
             *
             * @param m The matrix to assign.
             * @return Matrix<T>& A reference to this matrix.
             */
            Matrix &operator=(const Matrix &m)
            {
                if (this == &m)
                {
                    return *this;
                }

                if (rows_ != m.rows_ || cols_ != m.cols_)
                {
                    for (size_t i = 0; i < rows_; ++i)
                    {
                        delete[] p[i];
                    }
                    delete[] p;

                    rows_ = m.rows_;
                    cols_ = m.cols_;
                    allocSpace();
                }

                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        p[i][j] = m.p[i][j];
                    }
                }
                return *this;
            }
            
            /**
             * @brief Sets the value of a single element in the matrix.
             *
             * @param row The row index of the element to set.
             * @param col The column index of the element to set.
             * @param t The value to set the element to.
             */
            void setValue(size_t row, size_t col, T t)
            {
                if ((row < 0) || (row > rows_))
                {
                    Logger::log(Logger::log_level::Error, "Row index out of bounds.");
                }

                if ((col < 0) || (col > cols_))
                {
                    Logger::log(Logger::log_level::Error, "Column out of bounds.");
                }

                p[row][col] = t;
            }

            /**
             * @brief Fills the entire matrix with a single value.
             *
             * @param t The value to fill the matrix with.
             * @return Matrix<T>& A reference to this matrix.
             */
            Matrix<T> &fill(T t)
            {
                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        p[row][col] = t;
                    }
                }

                return *this;
            }
            
            /**
             * @brief Returns the value of a single element in the matrix.
             *
             * @param row The row index of the element.
             * @param col The column index of the element.
             * @return T The value of the element.
             */
            T getValue(size_t row, size_t col) const
            {
                if (row < 0 || row >= rows_)
                {
                    Logger::log(Logger::log_level::Error, "Row index out of bounds.");
                }

                if (col < 0 || col >= cols_)
                {
                    Logger::log(Logger::log_level::Error, "Column out of bounds.");
                }

                return p[row][col];
            }

            /*
                T &operator[](size_t const row, size_t const col) noexcept
                {
                    return p[row][col];
                }
                T const &operator[](size_t const row, size_t const col) const noexcept
                {
                    return p[row][col];
                }
            */
            /**
             * @brief Returns a reference to a single element in the matrix.
             *
             * @param row The row index of the element.
             * @param col The column index of the element.
             * @return T& A reference to the element.
             */
            inline T &operator()(size_t row, size_t col) const
            {
                if ((row < 0) || (row >= rows_))
                {
                    Logger::log(Logger::log_level::Error, "Row index out of bounds.");
                }

                if ((col < 0) || (col >= cols_))
                {
                    Logger::log(Logger::log_level::Error, "Column out of bounds.");
                }

                return p[row][col];
            }

            /**
             * @brief Adds the values of another matrix to this matrix.
             *
             * @param m The matrix to add.
             * @return Matrix<T>& A reference to this matrix.
             */
            Matrix &operator+=(const Matrix &m)
            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        p[i][j] += m.p[i][j];
                    }
                }
                return *this;
            }
            
            /**
             * @brief Subtracts the values of another matrix from this matrix.
             *
             * @param m The matrix to subtract.
             * @return Matrix<T>& A reference to this matrix.
             */
            Matrix &operator-=(const Matrix &m)
            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        p[i][j] -= m.p[i][j];
                    }
                }
                return *this;
            }
            
            /**
             * @brief Multiplies the values of this matrix by the values of another matrix.
             *
             * @param m The matrix to multiply by.
             * @return Matrix<T>& A reference to this matrix.
             */
            Matrix &operator*=(const Matrix &m)
            {
                if ((cols_ != m.rows_))
                {
                    Logger::log(Logger::log_level::Error, std::format("Incompatible matrix shapes for multiply. ({},{}) * ({},{})", rows_, cols_, m.rows_, m.cols_));
                }

                Matrix temp{rows_, m.cols_};
                for (size_t i = 0; i < temp.rows_; ++i)
                {
                    for (size_t j = 0; j < temp.cols_; ++j)
                    {
                        for (size_t k = 0; k < cols_; ++k)
                        {
                            temp.p[i][j] += (p[i][k] * m.p[k][j]);
                        }
                    }
                }
                return (*this = temp);
            }
            
            /**
             * @brief Adds a value to each element in the matrix.
             *
             * @param t The value to add.
             * @return Matrix<T>& A reference to this matrix.
             */
            Matrix &operator+=(T t)
            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        p[i][j] += t;
                    }
                }
                return *this;
            }
            
            /**
             * @brief Subtracts a value from each element in the matrix.
             *
             * @param t The value to subtract.
             * @return Matrix<T>& A reference to this matrix.
             */
            Matrix &operator-=(T t)
            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        p[i][j] -= t;
                    }
                }
                return *this;
            }
            
            /**
            * @brief Overload the *= operator to multiply the matrix by a scalar value
            @param t scalar value to multiply the matrix by
            * @return reference to the modified matrix
            */

            Matrix &operator*=(T t)
            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        p[i][j] *= t;
                    }
                }
                return *this;
            }
            
            /**
            * @brief Overload the /= operator to divide each element of the matrix by a scalar value
            * @param t scalar value to divide the matrix elements by
            * @return reference to the modified matrix
            */
            Matrix &operator/=(T t)
            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        p[i][j] /= t;
                    }
                }
                return *this;
            }
            
            /**
            * @brief Overload the ^ operator to raise each element of the matrix to a power
            * @param num power to raise the elements of the matrix to
            * @return reference to the modified matrix
            */
            Matrix &operator^(T num)
            {
                // do an element wise exponentiation

                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        p[row][col] = std::pow(p[row][col], (double)num);
                    }
                }

                return *this;
                // return expHelper(ret, num);
            }

            /*
            Matrix operator^(T num)
            {
                Matrix ret{*this};

                // do an element wise exponentiation

                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        ret.p[row][col] = std::pow(p[row][col], (double) num);
                    }
                }

                return ret;
                // return expHelper(ret, num);
            }
            */
            
            /**
            * @brief Get the number of rows in the matrix
            * @return number of rows in the matrix
            */
            size_t rows() const
            {
                return rows_;
            }

            /**
             * @brief Get the number of columns in the matrix
             * @return number of columns in the matrix
             */
            size_t cols() const
            {
                return cols_;
            }

            /**
            * @brief Get the total number of elements in the matrix
                @ return number of elements in the matrix *
            */
            size_t size() const
            {
                return rows_ * cols_;
            }

            /**
            * @brief Resize the matrix to a new number of rows and columns
            * @param rows new number of rows in the matrix
            * @param cols new number of columns in the matrix
            * @return reference to the modified matrix
            */
            Matrix &resize(size_t rows, size_t cols)
            {
                if ((rows < 0))
                {
                    Logger::log(Logger::log_level::Error, "Row index out of bounds.");
                }

                if ((cols < 0))
                {
                    Logger::log(Logger::log_level::Error, "Column out of bounds.");
                }

                freeSpace();

                rows_ = rows;
                cols_ = cols;

                allocSpace();

                return *this;
            }

            /**
            * @brief Reshape the matrix to a new number of rows and columns while preserving the number of elements.  One dimension can be -1, in which case its value is inferred from the length of the array and remaining dimensions.
            * @param rows new number of rows in the matrix.  If 0 is specified, rows is imputed from permissable shape.
            * @param cols new number of columns in the matrix.  If 0 is specified, cols is imputed from permissable shape.
            * @return new matrix with the reshaped dimensions
            */
            Matrix & reshape(size_t rows, size_t cols)
            {
                return ((*this) = Matrix::createReshape(*this, rows, cols));
            }

           /**
            * @brief Reshape the matrix to a new number of rows and columns while preserving the number of elements.  One dimension can be -1, in which case its value is inferred from the length of the array and remaining dimensions.
            * @param rows new number of rows in the matrix.  If 0 is specified, rows is imputed from permissable shape.
            * @param cols new number of columns in the matrix.  If 0 is specified, cols is imputed from permissable shape.
            * @return new matrix with the reshaped dimensions
            */
            static Matrix createReshape(const Matrix & m, size_t rows, size_t cols)
            {
                size_t size = m.size();

                if (rows == 0 && cols == 0)
                {
                    Logger::log(Logger::log_level::Error, "Rows and columns parameters cannot both be -1.");
                }

                if (rows == 0)
                {
                    rows = size / cols;
                }

                if (cols == 0)
                {
                    cols = size / rows;
                }

                if (rows * cols != size)
                {
                    Logger::log(Logger::log_level::Error, "The new shape is incompatible with the number of elements in the matrix.");
                }

                Matrix temp{size, 1};
                Matrix ret{rows, cols};

                size_t count = 0;

                for (size_t row = 0; row < m.rows(); ++row)
                {
                    for (size_t col = 0; col < m.cols(); ++col)
                    {
                        temp.p[count++][0] = m.p[row][col];
                    }
                }

                count = 0;

                for (size_t row = 0; row < rows; ++row)
                {
                    for (size_t col = 0; col < cols; ++col)
                    {
                        ret.p[row][col] = temp.p[count++][0];
                    }
                }

                return ret;
            }

            /**
            * @brief Swap the elements of two rows in the matrix
            * @param r1 index of the first row
            * @param r2 index of the second row
            */
            void swapRows(size_t r1, size_t r2)
            {
                if ((r1 < 0) || (r1 >= rows_))
                {
                    Logger::log(Logger::log_level::Error, "Row index out of bounds.");
                }

                if ((r2 < 0) || (r2 >= rows_))
                {
                    Logger::log(Logger::log_level::Error, "Row index out of bounds.");
                }

                T *temp = p[r1];
                p[r1] = p[r2];
                p[r2] = temp;
            }
            
            /**
            * @brief Create a new matrix that is the transpose of the original
            * @return new matrix that is the transpose of the original
            */
            Matrix createTranspose() const
            {
                Matrix ret{cols_, rows_};

                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        ret.p[col][row] = p[row][col];
                    }
                }
                return ret;
            }
            
            /**
            * @brief Transpose the matrix
            * @return new matrix that is the transpose of the original
            */
            Matrix transpose() const
            {
                return (*this).createTranspose();
            }
            
            /**
             * @brief Set all elements of the matrix to 1
             * @return reference to the modified matrix
             */
            Matrix &toOnes()
            {
                this->fill(1);

                return *this;
            }
            
            /**
            * @brief Set all elements of the matrix to 0
            * @return reference to the modified matrix
            */
            Matrix &toZeros()
            {
                this->fill(0);

                return *this;
            }
            
            /**
            * @brief Set all elements of the matrix to random values within a specified range
            * @param min minimum value for the random values
            * @param max maximum value for the random values
            * @return reference to the modified matrix
            */
            Matrix &toRandomValues(const double min = 0.0, const double max = 1.0)
            {
                std::random_device rd{}; // Will be used to obtain a seed for the random number engine
                std::mt19937 gen(rd());  // mersenne_twister_engine seeded with rd()
                std::normal_distribution<> distribution(min, max);

                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        p[row][col] = distribution(gen);
                    }
                }
                return *this;
            }
            
            /**
            * @brief Set the matrix to an identity matrix
            * @return reference to the modified matrix
            */
            Matrix &toIdentity()
            {
                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        (row == col) ? p[row][col] = 1 : p[row][col] = 0;
                    }
                }
                return *this;
            }
            
            /**
            * @brief Create a new matrix of ones with the specified number of rows and columns
            * @param rows number of rows in the new matrix
            * @param cols number of columns in the new matrix
            * @return new matrix with all elements set to 1
            */
            static Matrix createOnes(size_t rows, size_t cols)
            {
                if (rows < 0)
                {
                    Logger::log(Logger::log_level::Error, "Rows cannot be negative.");
                }

                if (cols < 0)
                {
                    Logger::log(Logger::log_level::Error, "Columns cannot be negative.");
                }

                Matrix temp{rows, cols};
                temp.toOnes();
                return temp;
            }

            /**
             * @brief Create a new matrix of zeros with the specified number of rows and columns
             * @param rows number of rows in the new matrix
             * @param cols number of columns in the new matrix
             * @return new matrix with all elements set to 0
             */
            static Matrix createZeros(size_t rows, size_t cols)
            {
                if (rows < 0)
                {
                    Logger::log(Logger::log_level::Error, "Rows cannot be negative.");
                }

                if (cols < 0)
                {
                    Logger::log(Logger::log_level::Error, "Columns cannot be negative.");
                }

                Matrix temp{rows, cols};
                temp.toZeros();
                return temp;
            }
            
            /**
            * @brief Create a new matrix of random values with the specified number of rows and columns
            * @param rows number of rows in the new matrix
            * @param cols number of columns in the new matrix
            * @return new matrix with random values between 0 and 1 for each element
            */
            static Matrix createRand(size_t rows, size_t cols)
            {
                if (rows < 0)
                {
                    Logger::log(Logger::log_level::Error, "Rows cannot be negative.");
                }

                if (cols < 0)
                {
                    Logger::log(Logger::log_level::Error, "Columns cannot be negative.");
                }

                Matrix ret{rows, cols};
                ret.toRandomValues();
                return ret;
            }

            /**
             * @brief Create a new matrix of random values with the specified number of rows and columns, with values distributed normally around 0
             * @param rows number of rows in the new matrix
             * @param cols number of columns in the new matrix
             * @return new matrix with random values distributed normally around 0
             */
            static Matrix createRandN(size_t rows, size_t cols)
            {
                if (rows < 0)
                {
                    Logger::log(Logger::log_level::Error, "Rows cannot be negative.");
                }

                if (cols < 0)
                {
                    Logger::log(Logger::log_level::Error, "Columns cannot be negative.");
                }

                T stdev = 1 / sqrt(rows * cols);
                std::normal_distribution<T> d{0, stdev};

                std::random_device rd{};
                std::mt19937 gen{rd()};

                Matrix ret{rows, cols};

                for (size_t row = 0; row < rows; ++row)
                {
                    for (size_t col = 0; col < cols; ++col)
                    {
                        ret.p[row][col] = d(gen);
                    }
                }
                return ret;
            }

            /**
             * @brief Create a new identity matrix with the specified size
             * @param size size of the new identity matrix (number of rows and columns)
             * @return new identity matrix
             */
            static Matrix createIdentity(size_t size)
            {
                if (size < 0)
                {
                    Logger::log(Logger::log_level::Error, "Size cannot be negative.");
                }

                Matrix ret{size, size};
                for (size_t i = 0; i < ret.rows_; ++i)
                {
                    ret.p[i][i] = 1;
                }
                return ret;
            }

            static Matrix createCategorical(const Matrix &m, size_t num_classes)
            {
                // Create a matrix of size (number of samples, num_classes)
                size_t num_samples = m.rows();

                Matrix ret{num_samples, num_classes};

                // For each sample, set the value in the corresponding column to 1
                for (size_t i = 0; i < num_samples; ++i)
                {
                size_t label = static_cast<size_t>(m.getValue(i, 0));
                ret.setValue(i, label, T(1));
                }

                return ret;
            }

            Matrix toCategorical(size_t num_classes)
            {
                return Matrix::createCategorical((*this), num_classes);
            }

            /**
             * @brief Create a new matrix that is the result of applying the given function element-wise on the original matrix
             * @param function function to apply element-wise to the matrix
             * @return new matrix with the function applied element-wise to the original matrix
             */
            Matrix apply_function(const std::function<T(const T &)> &function)
            {
                Matrix ret((*this));
                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        ret.p[row][col] = function(p[row][col]);
                    }
                }
                return ret;
            }

            /**
             * @brief Create a new matrix that is the result of applying the hyperbolic tangent function element-wise to the original matrix
             * @return new matrix with the hyperbolic tangent function applied element-wise to the original matrix
             */
            Matrix tanh() const
            {
                Matrix ret((*this));

                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        ret.p[row][col] = std::tanh(p[row][col]);
                    }
                }
                return ret;
            }

            /**
             * @brief Create a new matrix that is the element-wise exponential of the original matrix
             * @return new matrix with the hyperbolic tangent function applied element-wise to the original matrix
             */
            Matrix exp() const
            {
                Matrix ret((*this));

                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        ret.p[row][col] = std::exp(p[row][col]);
                    }
                }
                return ret;
            }

             /**
             * @brief Create a new matrix that is the element-wise maximum value as compared to t
             * @return new matrix with the maximum function applied element-wise to the original matrix
             */
            static Matrix maximum(const Matrix & m, T t)
            {

                size_t rows = m.rows();
                size_t cols = m.cols();

                Matrix ret{rows, cols};

                for (size_t row = 0; row < rows; ++row)
                {
                    for (size_t col = 0; col < cols; ++col)
                    {
                        ret.p[row][col] = std::max(m.p[row][col], t);
                    }
                }
                return ret;
            }


            /**
             * @brief Calculates the element-wise sum of the matrix
             * @return new matrix with the hyperbolic tangent function applied element-wise to the original matrix
             */
            T sum() const
            {
                T ret{};

                for (size_t row = 0; row < rows_; ++row)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        ret += p[row][col];
                    }
                }
                return ret;
            }

            /**
             * @brief Create a new matrix that is the result of performing a dot product between the original matrix and the given matrix, using broadcasting if necessary
             * @param m matrix to perform the dot product with
             * @return new matrix that is the result of the dot product between the original matrix and the given matrix
             */
            Matrix dotBroadcast(const Matrix &m) const
            {
                Matrix mt{};

                if (cols_ != m.rows_ && m.rows_ == 1)
                {
                    mt.resize(cols_, m.cols_);

                    // now broadcast m into mt
                    for (size_t row = 0; row < rows_; ++row)
                    {
                        for (size_t col = 0; col < m.cols_; ++col)
                        {
                            mt.p[row][col] = m.p[0][col];
                        }
                    }
                }
                else
                {
                    mt = m;
                }

                Matrix ret(rows_, m.cols_);

                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < m.cols_; ++j)
                    {
                        for (size_t k = 0; k < cols_; ++k)
                        {
                            ret.p[i][j] += (p[i][k] * mt.p[k][j]);
                        }
                    }
                }
                return ret;
            }

            /**
            @brief Calculates the mean value of the elements in the matrix.
            @return The mean value of the elements in the matrix.
            */
            T mean()
            {
                if (!(cols_ == 1 || rows_ == 1))
                {
                    Logger::log(Logger::log_level::Error, "Must be a vector.");
                }

                T ret{};
                T sum{};

                if (cols_ == 1)
                {
                    for (size_t row = 0; row < rows_; ++row)
                    {
                        sum += p[row][0];
                    }
                    ret = sum / (T)rows_;
                }
                else // if (rows_ == 1)
                {
                    for (size_t col = 0; col < cols_; ++col)
                    {
                        sum += p[0][col];
                    }
                    ret = sum / (T)cols_;
                }

                return ret;
            }

            /**
             * @brief Gets the shape of the matrix in the form of a pair (number of rows, number of columns).
             * @return A std::pair containing the number of rows and number of columns of the matrix.
             */
            std::pair<size_t, size_t> getShape() const
            {
                return std::make_pair(rows_, cols_);
            }

            /**
             * @brief Describes the shape of the matrix.
             * @return A string in the format "(number of rows, number of columns)".
             */
            std::string describeShape() const
            {
                return std::format("({},{})\n", rows_, cols_);
                //                return std::format("({},{}) : {}\n", rows_ , cols_, typeid(T).name());
            }

            /**
            * @brief Construct an array by repeating this matrix the number of times given by reps.
            * @param rowReps number of times to repeat the matrix.
            * @param colReps new number of columns in the matrix.
            * @return new matrix with the reshaped dimensions
            */
            Matrix tile(size_t rowReps, size_t colReps) const
            {
                Matrix ret{rows_ * rowReps, cols_ * colReps};

                for (size_t row = 0; row < rowReps; ++row)
                {
                    for (size_t col = 0; col < colReps; ++col)
                    {
                        const size_t rowStart = row * rows_;
                        const size_t colStart = col * cols_;

                        const size_t rowEnd = (row + 1) * rows_;
                        const size_t colEnd = (col + 1) * cols_;

                        for (size_t rowIdx = rowStart; rowIdx < rowEnd; ++rowIdx)
                        {
                            for (size_t colIdx = colStart; colIdx < colEnd; ++colIdx)
                            {
                                ret.p[rowIdx][colIdx] = p[rowIdx % rows_][colIdx % cols_];
                            }
                        }
                    }
                }

                return ret;
            }

            /**
             * @brief Filters a column vector matrix by a given value, creating a new matrix with only the elements that are equal to the value.
             * @param value The value to filter the matrix by.
             * @return A new matrix with only the elements of the original matrix that are equal to the value.
             */
            Matrix filterColumnVectorByValue(double value) const
            {
                std::vector<size_t> eq;

                for (size_t i = 0; i < rows_; ++i)
                {
                    if ((*this)(i, 0) == value)
                    {
                        eq.push_back(i);
                    }
                }

                Matrix a{eq.size(), 1};

                size_t insert{};

                for (size_t i : eq)
                {
                    a(insert, 0) = (*this)(i, 0);
                    insert++;
                }

                return a;
            }
            
            /**
             * @brief Splits the matrix into two based on a filter applied to a specified column.
             * @param column The column to apply the filter to.
             * @param threshold The value to use as the filter. Elements in the column that are less than the threshold will be placed in the first returned matrix, while elements that are equal to or greater than the threshold will be placed in the second returned matrix.
             * @return A std::pair containing two matrices, with the first matrix containing the elements that pass the filter and the second matrix containing the elements that do not pass the filter.
             */
            std::pair<Matrix, Matrix> splitByFilter(const size_t column, const double threshold) const
            {
                if ((column < 0) || (column > cols_))
                {
                    Logger::log(Logger::log_level::Error, "Column out of bounds.");
                }

                std::vector<size_t> less;
                std::vector<size_t> eq_or_more;

                for (size_t i = 0; i < rows_; ++i)
                {
                    if ((*this)(i, column) < threshold)
                    {
                        less.push_back(i);
                    }
                    else
                    {
                        eq_or_more.push_back(i);
                    }
                }

                Matrix a{less.size(), cols_};

                size_t insert{};

                for (size_t i : less)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        a(insert, j) = (*this)(i, j);
                    }
                    insert++;
                }

                Matrix b{eq_or_more.size(), cols_};

                insert = 0;

                for (size_t i : eq_or_more)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        b(insert, j) = (*this)(i, j);
                    }
                    insert++;
                }
                return std::make_pair(a, b);
            }
            
            /**
             * @brief Splits the matrix into two randomly, with a specified ratio of rows in the first matrix.
             * @param threshold The ratio of rows in the first returned matrix. Must be between 0 and 1.
             * @return A std::pair containing two matrices, with the first matrix containing a specified ratio of rows from the original matrix and the second matrix containing the remaining rows.
             */
            std::pair<Matrix, Matrix> splitRowsRandomly(const double threshold) const
            {
                if ((threshold < 0.0) || (threshold > 1.0))
                {
                    Logger::log(Logger::log_level::Error, "Threshold must be between 0 and 1.");
                }

                size_t numberToSelect{static_cast<size_t>(rows_ * threshold)};

                std::mt19937 generator(std::random_device{}());

                // distribution is inclusive
                std::uniform_int_distribution<std::size_t> distribution(0, rows_ - 1);

                bool *selectedRows = new bool[rows_];

                for (std::size_t n = 0; n < rows_; ++n)
                {
                    selectedRows[n] = false;
                }

                size_t numberSelected{};

                while (numberSelected < numberToSelect)
                {
                    size_t randomIndex = distribution(generator);

                    if (selectedRows[randomIndex] == false)
                    {
                        selectedRows[randomIndex] = true;
                        numberSelected++;
                    }
                }

                Matrix a{numberToSelect, cols_};
                Matrix b{rows_ - numberToSelect, cols_};

                size_t insertA{}, insertB{};

                for (size_t row = 0; row < rows_; ++row)
                {
                    if (selectedRows[row] == true)
                    {
                        for (size_t col = 0; col < cols_; ++col)
                        {
                            a(insertA, col) = (*this)(row, col);
                        }
                        insertA++;
                    }
                    else
                    {
                        for (size_t col = 0; col < cols_; ++col)
                        {
                            b(insertB, col) = (*this)(row, col);
                        }
                        insertB++;
                    }
                }

                delete[] selectedRows;

                return std::make_pair(a, b);
            }

            /**
            * @brief Splits this matrix into two at a row.
            * @param row The row index at which to split this matrix.
            * @return A pair of matrices, where the first matrix contains all rows of this matrix before and including the specified row, and the second matrix contains all rows after the specified row.
            * @throws std::invalid_argument if the row index is out of bounds.
            */
            std::pair<Matrix, Matrix> splitAtRow(const size_t row) const
            {
                if ((row < 0) || (row > rows_))
                {
                    Logger::log(Logger::log_level::Error, "Row out of bounds.");
                }

                Matrix a{row, cols_};
                Matrix b{rows_ - row, cols_};

                for (size_t i = 0; i < row; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        a(i, j) = (*this)(i, j);
                    }
                }

                for (size_t i = row; i < rows_ - row + 1; ++i)
                {
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        b(i - row, j) = (*this)(i, j);
                    }
                }

                return std::make_pair(a, b);
            }

            /**
            * @brief Splits this matrix into two matrices by row.
            * @param row The row index at which to split this matrix.
            * @return A vector of the matrices, where the first matrix contains all rows of this matrix before and including the specified row.
            * @throws std::invalid_argument if the row index is out of bounds.
            */
            std::vector<Matrix> splitIntoRows() const
            {
                std::vector<Matrix> ret{}; 

                for (size_t i = 0; i < rows_; ++i)
                {
                    Matrix m{1, cols_};
                    for (size_t j = 0; j < cols_; ++j)
                    {
                        m(0, j) = (*this)(i, j);
                    }
                    ret.push_back(m);
                }

                return ret;
            }
            
            /**
            * @brief Splits this matrix into two matrices by column.
            * @param column The column index at which to split this matrix.
            * @return A pair of matrices, where the first matrix contains all columns of this matrix before and including the specified column, and the second matrix contains all columns after the specified column.
            * @throws std::invalid_argument if the column index is out of bounds.
            */
            std::pair<Matrix, Matrix> splitAtColumn(const size_t column) const
            {
                if ((column < 0) || (column > cols_ - 1))
                {
                    Logger::log(Logger::log_level::Error, "Column out of bounds.");
                }

                Matrix a{rows_, column};
                Matrix b{rows_, cols_ - column};

                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = 0; j < column; ++j)
                    {
                        a(i, j) = (*this)(i, j);
                    }
                }

                for (size_t i = 0; i < rows_; ++i)
                {
                    for (size_t j = column; j < cols_; ++j)
                    {
                        b(i, j - column) = (*this)(i, j);
                    }
                }

                return std::make_pair(a, b);
            }
            
            /**
            * @brief Splits this matrix into two matrices by column.
            * @param column The column index at which to split this matrix.
            * @return A pair of matrices, where the first matrix contains all columns of this matrix before and including the specified column, and the second matrix contains all columns after the specified column.
            * @throws std::invalid_argument if the column index is out of bounds.
            */
            Matrix getColumn(const size_t column) const
            {
                if ((column < 0) || (column > cols_ - 1))
                {
                    Logger::log(Logger::log_level::Error, "Column out of bounds.");
                }

                Matrix a{rows_, 1};

                for (size_t i = 0; i < rows_; ++i)
                {
                    a(i, 0) = (*this)(i, column);
                }

                return a;
            }

            /**
            * @brief Extracts a row from this matrix.
            * @param row The index of the row to extract.
            * @return A matrix with a single row, containing the specified row from this matrix.
            * @throws std::invalid_argument if the row index is out of bounds.
            */
            Matrix getRow(const size_t row) const
            {
                if ((row < 0) || (row > rows_ - 1))
                {
                    Logger::log(Logger::log_level::Error, "Row out of bounds.");
                }

                Matrix a{1, cols_};

                for (size_t i = 0; i < cols_; ++i)
                {
                    a(0, i) = (*this)(row - 1, i);
                }

                return a;
            }

            /**
            * @brief Extracts the last column from this matrix.
            * @return A matrix with a single column, containing the last column of this matrix.
            */
            Matrix getLastColumn() const
            {
                return getColumn(cols_ - 1);
            }
 
            /**
            * @brief Inserts an additional column into this matrix.
            * @param columnNumber The index at which to insert the new columns.
            * @param m The matrix containing the new columns to insert.
            * @return A new matrix that is the result of inserting the columns from the given matrix into this matrix at the specified index.
            * @throws std::invalid_argument if the column index is out of bounds.
            */
            Matrix insertColumns(const size_t &columnNumber, Matrix &m)
            {
                if ((columnNumber < 0) || (columnNumber > cols_))
                {
                    Logger::log(Logger::log_level::Error, "Column out of bounds.");
                }

                Matrix temp{rows_, cols_ + m.cols_};

                for (size_t i = 0; i < temp.rows_; ++i)
                {
                    for (size_t j = 0; j < temp.cols_; ++j)
                    {
                        if (j < columnNumber)
                        {
                            temp(i, j) = (*this)(i, j);
                        }
                        else if ((j >= columnNumber) && (j <= columnNumber + m.cols_ - 1))
                        {
                            temp(i, j) = m(i, m.cols_ - 1 - j + columnNumber);
                        }
                        else
                        {
                            temp(i, j) = (*this)(i, j - m.cols_);
                        }
                    }
                }

                return *this = temp;
            }

            /**
             * @brief Prints the Matrix to the console.
             * @pre The type T must have an overloaded `operator<<` function for outputting to a std::ostream.
             */
            void print() const
            {
                std::cout << *this;
            }

            /**
            * @brief Overload the output stream operator to print a matrix.
            * @tparam T The type of the elements of the matrix.
            * @param os The output stream.
            * @param m The matrix to be printed.
            * @return std::ostream& The output stream.
            */
            template <class T>
            friend std::ostream &operator<<(std::ostream &os, const Matrix<T> &m);

            /**
            * @brief Overload the input stream operator to read a matrix.
            * @tparam T The type of the elements of the matrix.
            * @param is The input stream.
            * @param m The matrix to be read.
            * @return std::istream& The input stream.
            */
            template <class T>
            friend std::istream &operator>>(std::istream &is, Matrix<T> &m);

        private:
            /**
            * @brief Allocate space for the matrix.
            This function is used to allocate space for the matrix when it is created or resized.
            */
            void allocSpace()
            {
                p = new T *[rows_];
                for (size_t row = 0; row < rows_; ++row)
                {
                    p[row] = new T[cols_]{};
                }
            }
            
            /**
            * @brief Free the space used by the matrix.
            This function is used to free the space used by the matrix when it is destroyed or resized.
            */
            void freeSpace()
            {
                for (size_t i = 0; i < rows_; ++i)
                {
                    delete[] p[i];
                }
                delete[] p;
            }
            
            /**
            @brief Free the space used by the matrix.
            This function is used to free the space used by the matrix when it is destroyed or resized.
            */
            static Matrix expHelper(Matrix m, size_t num)
            {
                if (num == 0)
                {
                    return createIdentity(m.rows_);
                }
                else if (num == 1)
                {
                    return m;
                }
                else if (num % 2 == 0)
                { // num is even
                    if (m.cols_ != m.rows_)
                    {
                        return expHelper(m.transpose() * m, num / 2);
                    }
                    else
                    {
                        return expHelper(m * m, num / 2);
                    }
                }
                else
                { // num is odd
                    if (m.cols_ != m.rows_)
                    {
                        return m * expHelper(m.transpose() * m, (num - 1) / 2);
                    }
                    else
                    {
                        return expHelper(m * m, num / 2);
                    }
                }
            }
        };

        /**
         * @brief Converts a value to a string.
         * @tparam T The type of the value to convert.
         * @param t The value to convert.
         * @return A string representation of the value.
         *
         * @pre The type T must have an overloaded `operator<<` function for outputting to a std::ostream.
         */
        template <class T>
        static std::string to_string(const T &t)
        {
            std::ostringstream s;
            s << t;
            return s.str();
        }

        /**
        * @brief Overloads the stream insertion operator to allow for the easy printing of Matrix objects.
        * @param os Output stream.
        * @param m Matrix object to be printed.
        * @return Output stream with the matrix data appended.
        This function is a friend function of the Matrix class, allowing it to access the private member variables of Matrix objects.
        It iterates through the elements of the matrix and inserts them into the output stream, separated by spaces. It also adds padding to align the elements in a grid.
        */
        template <class T>
        std::ostream &operator<<(std::ostream &os, const Matrix<T> &m)
        {
            int *spacing = new int[m.cols_];

            for (size_t j = 0; j < m.cols_; ++j)
            {
                size_t max = 0;

                for (size_t i = 0; i < m.rows_; ++i)
                {
                    size_t length = to_string(m.p[i][j]).length();
                    if (max < length)
                        max = length;
                }

                spacing[j] = max + (j != 0);
            }

            for (size_t i = 0; i < m.rows_; ++i)
            {
                for (size_t j = 0; j < m.cols_; ++j)
                {
                    os << std::setw(spacing[j]) << std::right << m.p[i][j];
                }
                os << '\n';
            }

            return os;
        }
        
        /**
        * @brief Overloads the stream extraction operator to allow for the easy input of Matrix objects.
        * @param is Input stream.
        * @param m Matrix object to store the input data.
        * @return Input stream with the data read from it.
        This function is a friend function of the Matrix class, allowing it to access the private member variables of Matrix objects.
        It iterates through the elements of the matrix and extracts them from the input stream, storing them in the corresponding element of the matrix.
        */
        template <class T>
        std::istream &operator>>(std::istream &is, Matrix<T> &m)
        {
            for (size_t i = 0; i < m.rows_; ++i)
            {
                for (size_t j = 0; j < m.cols_; ++j)
                {
                    is >> m.p[i][j];
                }
            }
            return is;
        }
        
        /**
        * @brief Overloads the addition operator to allow for the addition of two Matrix objects.
        * @param m1 First matrix operand.
        * @param m2 Second matrix operand.
        * @return Matrix object resulting from the element-wise addition of the two operands.
        This function checks that the two operands have the same dimensions and throws an exception if they do not.
        It then iterates through the elements of the matrices and adds the corresponding elements, storing the result in a new Matrix object which it returns.
        */
        template <class T>
        Matrix<T> operator+(const Matrix<T> &m1, const Matrix<T> &m2)
        {
            Matrix<T> temp(m1);
            return temp += m2;
        }
        
        /**
        * @brief Overloads the subtraction operator to allow for the subtraction of two Matrix objects.
        * @param m1 Matrix operand to be subtracted from.
        * @param m2 Matrix operand to subtract.
        * @return Matrix object resulting from the element-wise subtraction of the second operand from the first.
        This function checks that the two operands have the same dimensions and throws an exception if they do not.
        It then iterates through the elements of the matrices and subtracts the corresponding elements of the second operand from the first, storing the result in a new Matrix object which it returns.
        */
        template <class T>
        Matrix<T> operator-(const Matrix<T> &m1, const Matrix<T> &m2)
        {
            Matrix temp(m1);
            return temp -= m2;
        }
        
        /**
         * @brief Overloads the * operator to perform matrix multiplication between two matrices.
         *
         * @tparam T The type of the elements in the matrices.
         * @param m1 The first matrix.
         * @param m2 The second matrix.
         * @return A matrix that is the result of multiplying m1 by m2.
         *
         * @pre The number of columns in m1 must be equal to the number of rows in m2.
         * @post The resulting matrix will have the same number of rows as m1 and the same number of columns as m2.
         */
        template <class T>
        Matrix<T> operator*(const Matrix<T> &m1, const Matrix<T> &m2)
        {
            Matrix temp(m1);
            return temp *= m2;
        }
        
        /**
         * @brief Overloads the + operator to add a scalar value to all elements in a matrix.
         *
         * @tparam T The type of the elements in the matrix.
         * @param m The matrix.
         * @param t The scalar value to add.
         * @return A matrix with all elements increased by t.
         *
         * @post The resulting matrix will have the same size and shape as the original matrix.
         */
        template <class T>
        Matrix<T> operator+(const Matrix<T> &m, T t)
        {
            Matrix temp(m);
            return temp += t;
        }
        
        /**
         * @brief Overloads the + operator to add a scalar value to all elements in a matrix.
         *
         * @tparam T The type of the elements in the matrix.
         * @param t The scalar value to add.
         * @param m The matrix.
         * @return A matrix with all elements increased by t.
         *
         * @post The resulting matrix will have the same size and shape as the original matrix.
         */
        template <class T>
        Matrix<T> operator+(T t, const Matrix<T> &m)
        {
            Matrix temp(m);
            return temp += t;
        }
        
        /**
         * @brief Overloads the - operator to subtract a scalar value from all elements in a matrix.
         *
         * @tparam T The type of the elements in the matrix.
         * @param m The matrix.
         * @param t The scalar value to subtract.
         * @return A matrix with all elements decreased by t.
         *
         * @post The resulting matrix will have the same size and shape as the original matrix.
         */
        template <class T>
        Matrix<T> operator-(const Matrix<T> &m, T t)
        {
            Matrix temp(m);
            return temp -= t;
        }
        
        /**
         * @brief Overloads the - operator to subtract a matrix from a scalar value.
         *
         * @tparam T The type of the elements in the matrix.
         * @param t The scalar value.
         * @param m The matrix.
         * @return A matrix with all elements equal to t minus the corresponding element in m.
         *
         * @post The resulting matrix will have the same size and shape as the original matrix.
         */
        template <class T>
        Matrix<T> operator-(T t, const Matrix<T> &m)
        {
            Matrix temp(m);

            for (size_t row = 0; row < m.rows(); ++row)
            {
                for (size_t col = 0; col < m.cols(); ++col)
                {
                    temp.setValue(row, col, t - m.getValue(row, col));
                }
            }

            return temp;
        }
        
        /**
         * @brief Overloads the * operator to multiply a matrix by a scalar value.
         *
         * @tparam T The type of the elements in the matrix.
         * @param m The matrix.
         * @param t The scalar value to multiply by.
         * @return A matrix with all elements multiplied by t.
         *
         * @post The resulting matrix will have the same size and shape as the original matrix.
         */
        template <class T>
        Matrix<T> operator*(const Matrix<T> &m, T t)
        {
            Matrix temp(m);
            return temp *= t;
        }
        
        /**
         * @brief Overloads the * operator to multiply a scalar value by a matrix.
         *
         * @tparam T The type of the elements in the matrix.
         * @param t The scalar value to multiply by.
         * @param m The matrix.
         * @return A matrix with all elements multiplied by t.
         *
         * @post The resulting matrix will have the same size and shape as the original matrix.
         */
        template <class T>
        Matrix<T> operator*(T t, const Matrix<T> &m)
        {
            return m * t;
        }
        
        /**

        * @brief Overloads the '/' operator to perform element-wise division on two matrices.
        * @tparam T The type of the elements in the matrix.
        * @param m1 The first matrix.
        * @param t The scalar value to divide the matrix by.
        * @return The matrix resulting from element-wise division.
        * @pre The type T must have a '/' operator defined.
        */
        template <class T>
        Matrix<T> operator/(const Matrix<T> &m, T t)
        {
            Matrix<T> temp(m);
            return temp /= t;
        }
    }
}
