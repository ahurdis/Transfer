#pragma once

#include <iostream>
#include <map>
#include <string>

// function to calculate all the prime factors and
// count of every prime factor
std::map<unsigned long long, unsigned long long> factorize(unsigned long long n)
{
    std::map<unsigned long long, unsigned long long> m;

    int count = 0;

    // count the number of times 2 divides
    while (!(n % 2))
    {
        n >>= 1; // equivalent to n=n/2;
        count++;
    }

    m[2] = count;

    /*
    // if 2 divides it
    if (count)
        std::cout << 2 << " " << count << std::endl;
*/

    // check for all the possible numbers that can
    // divide it
    for (long long i = 3; i <= sqrt(n); i += 2)
    {
        count = 0;
        while (n % i == 0)
        {
            count++;
            n = n / i;
        }

        m[i] = count;

        /*
		if (count)
			std::cout << i << " " << count << std::endl;
*/
    }

    // if n at the end is a prime number.
    if (n > 2)
        m[n] = 1;
    // std::cout << n << " " << 1 << std::endl;

    return m;
}

std::string rtrim_multiplication(std::string &s)
{
    s.erase(std::find_if(s.rbegin(), s.rend(), [](int ch)
                            { return !(ch == '*' || std::isspace(ch)); })
                .base(),
            s.end());
    return s;
}

std::string printFactors(std::map<unsigned long long, unsigned long long> factorMap)
{
    std::string strRet {};

    for (std::map<unsigned long long, unsigned long long>::iterator it = factorMap.begin(); it != factorMap.end(); ++it)
    {
        // key.push_back(it->first);
        // value.push_back(it->second);

        if (it->second != 0)
        {
            strRet += std::to_string(it->first);

            if (it->second != 1)
            {
                strRet += "^" + std::to_string(it->second);
            }

            strRet += " * ";
        }
    }

    return rtrim_multiplication(strRet);
}