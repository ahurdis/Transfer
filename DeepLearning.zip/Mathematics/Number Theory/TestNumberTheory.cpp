/**
 *  Given two numbers, determine the greatest common divisior of the two numbers.
 */

#include <iostream>
#include <map>
#include <cmath>
#include <cassert>

#include "GreatestCommonDenominator.h"
#include "PrimeFactorization.h"
#include "Fibonacci.h"
#include "NChooseR.h"

using namespace std;

using Z = unsigned long long;


void testPrimeFactorization()
{
    for (Z i = 10000101017; i < 10000101317; i++)
    {
        map<Z, Z> factorMap = factorize(i);
        cout << i << " : " << printFactors(factorMap) << endl;
    }
}

Z factorial(Z i)
{
    if (i <= 1)
        return 1;
    return i * factorial(i - 1);
}

void testGreatestCommonDenominator()
{
    int a, b;
    cout << "Enter number 1 : ";
    cin >> a;
    cout << "Enter number 2 : ";
    cin >> b;
    cout << "GCD of " << a << " and "
         << b << " is " << gcd1(a, b) << endl;
    cout << "GCD of " << a << " and "
         << b << " is " << gcd2(a, b) << endl;
    cout << "GCD of " << a << " and "
         << b << " is " << gcd3(a, b) << endl;
    cout << "GCD of " << a << " and "
         << b << " is " << gcd4(a, b) << endl;
}

Z eta(Z prime, Z n)
{
    return factorize(factorial(n))[prime];
}

Z ipow(Z base, Z exp)
{
    Z result = 1ULL;
    while (exp)
    {
        if (exp & 1)
        {
            result *= (Z)base;
        }
        exp >>= 1;
        base *= base;
    }
    return result;
}

Z fast_eta(Z prime, Z n)
{
    Z sum = 0ULL;
    Z exp = 1ULL;
    Z term = 0ULL;

    do
    {
        term = std::floor(n / ipow(prime, exp));
        sum += term;
        exp += 1;
    } while (term > 0);

    return sum;
}

void testNChooseR()
{
    uint8_t t = n_choose_r(5, 2);
    assert(((void)"10 is the answer but function says otherwise.\n", t == 10));
    std::cout << "First test passes." << std::endl;
    // Second test on 5 choose 3

}


int main()
{

/*
    Z prime = 2ULL;
    Z n = 10ULL;

    cout << eta(prime, n) << endl;
    cout << fast_eta(prime, n) << endl;

    cout << fibonacci(23) << endl;
*/

    //    testPrimeFactorization();
    // testGreatestCommonDenominator();

    testNChooseR();

    return 0;
}