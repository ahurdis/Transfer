#pragma once

/*
    Fibonacci number
    -----------------
    The Fibonacci numbers form a sequence denoted F(n) in which each number is the sum of the two preceding ones.

    Time complexity
    ---------------
    O(n), where n is the term of the Fibonacci sequence to calculate.

    Space complexity
    ----------------
    O(1).
*/

using Z = unsigned long long;

const int MAX_FIB = 93;   // F(94) exceeds range of ULL

Z fibonacci(const Z n)
{
    if (n > MAX_FIB)
        return -1;

    if (n == 0 || n == 1)
        return n; // F(0) = 0, and F(1) = 1

    Z previous_to_previous = 0; // F(n-2)
    Z previous = 1;             // F(n-1)
    Z fn;                       // F(n)

    for (int term = 2; term <= n; term++)
    {
        fn = previous + previous_to_previous; // F(n) = F(n-1) + F(n-2)
        previous_to_previous = previous;      // F(n-1) becomes F(n-2) in the next step
        previous = fn;                        // F(n) becomes F(n-1) in the next step
    }

    return fn;
}

Z fibonacci_recursive(const Z n)
{
    if (n > MAX_FIB)
        return -1;

    if (n <= 1)
        return n;

    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2);
}