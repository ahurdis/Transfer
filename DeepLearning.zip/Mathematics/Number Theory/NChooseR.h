
template <class T>
T n_choose_r(T n, T r) {
    if (r > n / 2) {
        r = n - r;  // Because of the fact that  nCr(n, r) == nCr(n, n - r)
    }
    T ans = 1;
    for (int i = 1; i <= r; i++) {
        ans *= n - r + i;
        ans /= i;
    }
    return ans;
}
