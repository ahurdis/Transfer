#include <concepts>
#include <ostream>
#include <numeric>

#pragma once

template <std::integral T = size_t>
class Rational
{
public:
    Rational(T number) : numerator_(number), denominator_(T(1)) {}

    Rational(T numerator, T denominator) : numerator_(numerator), denominator_(denominator)
    {
        if (denominator == 0)
            throw "Denominator cannot be zero.";
        reduce();
    }

    Rational(const Rational<T> &r) : numerator_(r.numerator_), denominator_(r.denominator_) {}

    void operator=(const Rational<T> &rhs)
    {
        numerator_ = rhs.numerator_;
        denominator_ = rhs.denominator_;
    }

    void operator=(const T &rhs)
    {
        numerator_ = rhs;
        denominator_ = 1;
    }

    operator double() const
    {
        return numerator_ / (double)denominator_;
    }

    bool operator==(const Rational<T> &rhs) const
    {
        return numerator_ * rhs.denominator_ == denominator_ * rhs.numerator_;
    }

    bool operator<(const Rational<T> &rhs) const
    {
        return numerator_ * rhs.denominator_ < denominator_ * rhs.numerator_;
    }

    bool operator<=(const Rational<T> &rhs) const
    {
        return numerator_ * rhs.denominator_ <= denominator_ * rhs.numerator_;
    }

    bool operator>(const Rational<T> &rhs) const
    {
        return !((*this) <= rhs);
    }

    bool operator>=(const Rational<T> &rhs) const
    {
        return !((*this) < rhs);
    }

    bool operator!=(const Rational<T> &rhs) const
    {
        return !((*this) == rhs);
    }

    Rational<T> &operator+=(const Rational<T> &rhs)
    {
        numerator_ = numerator_ * rhs.denominator_ +
                     rhs.numerator_ * denominator_;
        denominator_ *= rhs.denominator_;
        reduce();
        return *this;
    }

    Rational<T> operator+(const Rational<T> &rhs) const
    {
        return Rational(*this) += rhs;
    }

    Rational<T> &operator*=(const Rational<T> &rhs)
    {
        numerator_ *= rhs.numerator_;
        denominator_ *= rhs.denominator_;
        reduce();
        return *this;
    }

    Rational<T> operator*(const Rational<T> &rhs) const
    {
        return Rational(*this) *= rhs;
    }

    Rational<T> &operator/=(const Rational<T> &rhs)
    {
        return (*this *=  rhs.inverse());
    }

    Rational<T> operator/(const Rational<T> &rhs) const
    {
        return Rational(*this) * rhs.inverse();
    }

    Rational<T> operator-()
    {
        return Rational(-numerator_, denominator_);
    }

    Rational<T> inverse() const
    {
        if (numerator_ == 0)
            throw "Cannot invert because demoninator would be zero.";

        return Rational(denominator_, numerator_);
    }

    void reduce()
    {
        T cd = std::gcd(numerator_, denominator_);
        bool negative = (numerator_ >= 0) ^ (denominator_ >= 0);
        if (cd == 0)
        {
            numerator_ = 0;
            denominator_ = 1;
        }
        else
        {
            numerator_ = std::abs(numerator_) / cd * (negative ? -1 : 1);
            denominator_ = std::abs(denominator_) / cd;
        }
    }

private:
    T numerator_;
    T denominator_;

public:
    T &numerator = numerator_;
    T &denominator = denominator_;
};

template <typename T>
std::ostream &operator<<(std::ostream &os, const Rational<T> &rhs)
{
    os << rhs.numerator;
    if (rhs.denominator != T(1))
        os << "/" << rhs.denominator;
    return os;
}