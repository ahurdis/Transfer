#include <iostream>

#include "Rational.h"

int main()
{
    Rational r{22, 7};

    Rational t{3, 5};

    std::cout << "r is " << r << '\n';
    std::cout << "t is " << t << '\n';

    if (r > t) std::cout << "r is greater than t" << '\n';
    if (r >= t) std::cout << "r is greater than or equal to t" << '\n';
    if (r == t) std::cout << "r is equal to t" << '\n';
    if (r <= t) std::cout << "r is less than or equal to t" << '\n';
    if (r < t) std::cout << "r is less than t" << '\n';
    if (r != t) std::cout << "not equal" << '\n';

    std::cout << "r * t = " << r * t << '\n';
    std::cout << "t / t = " << t / t << '\n';


    std::cout << "r as a real is " << (double) r << '\n';

    std::cout << "t + r = " << t + r << '\n';
    std::cout << "t * r = " << t * r << '\n';
    std::cout << "-t = " << -t << '\n';

}