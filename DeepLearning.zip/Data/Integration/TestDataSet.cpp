#include <iostream>
#include <numeric>
#include "DataSet.h"

#include "..\..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;

using namespace Data::Integration;

void testDataSet(DataSet &ds)
{
    std::cout << "Header Row " << '\n';
    ds.printHeaderRow();

    std::cout << "value of 1, 1 is " << '\n';
    std::cout << ds.getValue(1, 1) << '\n';

    std::cout << "x Column as string" << '\n';
    std::cout << ds.getColumn("x") << '\n';

    std::cout << "values of row 2 are " << '\n';
    std::cout << ds.getRow(2) << '\n';


    std::cout << "This set has " << ds.getNumberOfRows() << " rows." << '\n';

    std::cout << "This set has " << ds.getNumberOfColumns() << " columns." << '\n';

    std::cout << "The set as a matrix: " << '\n';
    Matrix<double> &M = ds.getMatrix();
    std::cout << M << '\n';

    auto [x, y] = ds.splitAtColumn(1);
    x.printHeaderRow();  
    std::cout << x.getMatrix() << '\n';
    y.printHeaderRow();  
    std::cout << y.getMatrix() << '\n';
}

int main()
{
    DataSet ds("Data/Integration/dummy.csv");

    testDataSet(ds);

    return EXIT_SUCCESS;
}