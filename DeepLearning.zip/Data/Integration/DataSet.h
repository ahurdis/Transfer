#pragma once

#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <vector>

#include "..\..\Utilities\String\LexicCast.h"
#include "..\..\Utilities\String\StringUtilities.h"
#include "..\..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;
using namespace Utilities::String;

namespace Data::Integration
{
    class DataSet
    {
    public:
        DataSet(const std::string &file_path,
                const char &delimiter = ',',
                const bool &hasHeader = true,
                const bool &loadImmediately = true)
            : _file_path(file_path), _delimiter(delimiter), _hasHeader(hasHeader)
        {
            if (loadImmediately)
            {
                loadFile();
                _m = toMatrix();
                _csv_contents.clear();
                _file_contents.clear();
            }
        }

        DataSet(const Matrix<double> &m, const std::vector<std::string> &header_row)
            : _m(m), _header_row(header_row)
        {
        }

        Matrix<double> &getMatrix()
        {
            return _m;
        }

    public:
        std::pair<DataSet, DataSet> splitAtColumn(const size_t column) const
        {
            auto [x, y] = _m.splitAtColumn(column);

            auto [headerX, headerY] = splitHeaderRow(column);

            // creating the pair and working with it via reference saves copy in std::make_pair
            std::pair<DataSet, DataSet> result(DataSet{x, headerX}, DataSet{y, headerY});

            return result;
        }

        std::pair<DataSet, DataSet> splitAtLastColumn() const
        {
            return splitAtColumn(getNumberOfColumns() - 1);
        }

        void loadFile()
        {
            std::ifstream in(_file_path);
            if (in.fail())
                std::cout << "File " + _file_path + " not found." << '\n';

            bool headerParsed = false;

            int counter = 0;

            while (in.good())
            {
                std::vector<std::string> items = csv_read_row(in);

                _parsedColumns = std::max(_parsedColumns, items.size());

                if (!headerParsed && _hasHeader)
                {
                    _header_row = items;
                    headerParsed = true;
                }
                else
                {
                    _csv_contents[counter] = items;
                    counter += 1;
                }

                items.clear();
            }
            in.close();
        }

        void printHeaderRow() const
        {
            if (_hasHeader)
            {
                for (auto i : _header_row)
                {
                    std::cout << i << ' ';
                }
                std::cout << '\n';
            }
            else
            {
                std::cout << "File has no header." << '\n';
            }
        }

        // TODO : Add bounds checking
        std::pair<std::vector<std::string>, std::vector<std::string>> splitHeaderRow(const size_t column) const
        {
            std::vector<std::string> v1(_header_row.begin(), _header_row.begin() + column);
            std::vector<std::string> v2(_header_row.begin() + column, _header_row.end());

            return std::make_pair(v1, v2);
        }

        std::string getLastColumnHeader() const
        {
            return _header_row.back();
        }

        double getValue(const size_t row, const size_t col) const
        {
            return _m(row, col);
        }

        /// Returns the number of rows in the training set.
        size_t getNumberOfRows() const
        {
            return _m.rows();
        }

        /// Returns the number of rows in the training set.
        size_t getNumberOfColumns() const
        {
            return _m.cols();
        }

        std::pair<size_t, size_t> shape() const
        {
            return std::make_pair(_m.rows(), _m.cols());
        }

        Matrix<double> getColumn(const std::string &columnHeader) const
        {
            Matrix<double> ret;

            if (_hasHeader)
            {
                auto foundIt = std::find(_header_row.begin(), _header_row.end(), columnHeader);

                auto column{-1};

                if (foundIt != _header_row.end())
                {
                    column = foundIt - _header_row.begin();
                }

                if (column != -1)
                {
                    ret = _m.getColumn(column);
                }
            }
            return ret;
        }

        std::vector<double> getColumnAsVector(const size_t column) const
        {
            std::vector<double> ret;

            Matrix<double> a = _m.getColumn(column);

            for (size_t i = 0; i < a.rows(); ++i)
            {
                ret.push_back(a(i, 0));
            }

            return ret;
        }

        Matrix<double> getColumn(const size_t column) const
        {
            return _m.getColumn(column);
        }

        DataSet getLastColumn() const
        {
            auto [x, last] = splitHeaderRow(_header_row.size() - 1);

            DataSet ds(_m.getLastColumn(), last);

            return ds;
        }

        Matrix<double> getRow(const size_t row) const
        {
            return _m.getRow(row);
        }

        std::pair<DataSet, DataSet> splitByFilter(const size_t column, const double threshold) const
        {
            auto [x, y] = _m.splitByFilter(column, threshold);

            std::pair<DataSet, DataSet> result(DataSet{x, _header_row}, DataSet{y, _header_row});

            return result;
        }

        std::pair<DataSet, DataSet> splitRowsRandomly(const double threshold) const
        {
            auto [x, y] = _m.splitRowsRandomly(threshold);

            std::pair<DataSet, DataSet> result(DataSet{x, _header_row}, DataSet{y, _header_row});

            return result;
        }

        std::pair<DataSet, DataSet> splitAtRow(const size_t row) const
        {
            auto [x, y] = _m.splitAtRow(row);

            std::pair<DataSet, DataSet> result(DataSet{x, _header_row}, DataSet{y, _header_row});

            return result;
        }

        DataSet filterColumnVectorByValue(double value) const
        {
            return DataSet{_m.filterColumnVectorByValue(value), _header_row};
        }

        std::vector<Matrix<double>> normalizePixels(std::vector<Matrix<double>> && vm)
        {   
            for (auto & m : vm)
            {
                m /= 255.0;
                m.reshape(28, 28);
            }
            return vm; 
        };

        Matrix<double> toCategorical(Matrix<double> & m, size_t num_classes)
        {   
            return m.toCategorical(num_classes);
        };

        std::tuple<std::vector<Matrix<double>>, std::vector<Matrix<double>>,
                   std::vector<Matrix<double>>, std::vector<Matrix<double>>>
        splitAtRow(const size_t row, const size_t col)
        {
            // Split the dataset into the training and testing dataset
            auto [train, test] = _m.splitAtRow(row);

            auto [train_y, train_x] = train.splitAtColumn(col);
            auto [test_y, test_x] = test.splitAtColumn(col);

            return std::make_tuple(normalizePixels(train_x.splitIntoRows()), toCategorical(train_y, 10).splitIntoRows(),
                                   normalizePixels(test_x.splitIntoRows()), toCategorical(test_y, 10).splitIntoRows());
        }

        std::tuple<std::vector<Matrix<double>>, std::vector<Matrix<double>>,
                   std::vector<Matrix<double>>, std::vector<Matrix<double>>>
        split(const double threshold, const size_t col)
        {
            // Split the dataset into the training and testing dataset
            auto [train, test] = _m.splitRowsRandomly(threshold);

            auto [train_y, train_x] = train.splitAtColumn(col);
            auto [test_y, test_x] = test.splitAtColumn(col);

            return std::make_tuple(normalizePixels(train_x.splitIntoRows()), toCategorical(train_y, 10).splitIntoRows(),
                                   normalizePixels(test_x.splitIntoRows()), toCategorical(test_y, 10).splitIntoRows());
        }

        Matrix<double> &toMatrix()
        {
            _m.resize(getNumberOfParsedRows(), getNumberOfParsedColumns());

            size_t row{}, col{};

            for (auto const &[key, val] : _csv_contents)
            {
                col = 0;

                for (auto &str : val)
                {
                    std::string_view sv{str};

                    const char *unparsed_str;

                    try
                    {
                        auto parsed_num{lexic_cast<double>(sv, &unparsed_str)};
                        //                        double rounded = round_prec(parsed_num, 2);
                        _m.setValue(row, col, parsed_num);
                    }
                    catch (std::runtime_error &e)
                    {
                        std::cout << "Bummer! " << e.what() << '\n';
                    }

                    col++;
                }

                row++;
            }
            return _m;
        }

    private:
        /// Returns the number of rows in the training set.
        size_t getNumberOfParsedRows() const
        {
            return _csv_contents.size();
        }

        /// Returns the number of rows in the training set.
        size_t getNumberOfParsedColumns() const
        {
            return _parsedColumns;
        }

        long long ipow(int base, int exp)
        {
            int result = 1;
            while (true)
            {
                if (exp & 1)
                    result *= base;
                exp >>= 1;
                if (exp == 0)
                    break;
                base *= base;
            }

            return result;
        }

        double round_prec(double n, int prec)
        {
            return std::round(n * ipow(10, prec)) / ipow(10, prec);
        }

        std::vector<std::string> csv_read_row(std::istream &in) const
        {
            std::stringstream ss;
            bool inquotes = false;
            std::vector<std::string> row; // relying on RVO
            while (in.good())
            {
                char c = in.get();
                if (!inquotes && c == '"') // beginquotechar
                {
                    inquotes = true;
                }
                else if (inquotes && c == '"') // quotechar
                {
                    if (in.peek() == '"') // 2 consecutive quotes resolve to 1
                    {
                        ss << (char)in.get();
                    }
                    else // endquotechar
                    {
                        inquotes = false;
                    }
                }
                else if (!inquotes && c == _delimiter) // end of field
                {
                    row.push_back(ss.str());
                    ss.str("");
                }
                else if (!inquotes && (c == '\r' || c == '\n'))
                {
                    if (in.peek() == '\n')
                    {
                        in.get();
                    }
                    row.push_back(ss.str());
                    return row;
                }
                else
                {
                    ss << c;
                }
            }
        }

    private:
        std::string _file_path{};
        char _delimiter{','};
        bool _hasHeader{true};

        std::string _file_contents{};
        std::map<int, std::vector<std::string>> _csv_contents{};
        std::vector<std::string> _header_row{};
        size_t _parsedColumns{};

        Matrix<double> _m{};
    };
}
