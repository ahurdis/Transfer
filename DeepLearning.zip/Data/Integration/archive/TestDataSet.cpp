#include <iostream>
#include <numeric>
#include "DataSet.h"

#include "..\..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;

using namespace Data::Integration;

void testDataSet(DataSet &ds)
{
    std::cout << "Header Row " << '\n';
    ds.printHeaderValues();

    std::cout << "value of 1, 1 is " << '\n';
    ds.printValue(1, 1);

    std::cout << "x Column as string" << '\n';
    ds.printColumnValues("x");

    std::cout << "y Column as string" << '\n';
    ds.printColumnValues("y");

    std::cout << "values of row 2 are " << '\n';
    ds.printRowValues(2);

    std::cout << "This set has " << ds.getNumberOfRows() << " rows." << '\n';

    std::cout << "This set has " << ds.getNumberOfColumns() << " columns." << '\n';

    std::cout << "The set as a matrix: " << '\n';
    Matrix<double> &M = ds.toMatrix();
    std::cout << M << '\n';

    std::cout << "The X column as double is: " << '\n';
    std::vector<double> vd = ds.getColumnAsValue("x");
    for (auto d : vd)
    {
        std::cout << d << ' ';
    }
    std::cout << '\n';

    std::cout << "The Column X as a column matrix: " << '\n';
    Matrix<double> X(vd);
    std::cout << X << '\n';
}

int main()
{
    DataSet ds("Data/Integration/closed.csv");

    testDataSet(ds);

    return EXIT_SUCCESS;
}