#pragma once

#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <string_view>
#include <map>

#include "..\..\Utilities\String\LexicCast.h"
#include "..\..\Utilities\String\StringUtilities.h"
#include "..\..\Mathematics\Matrix\Matrix.h"

using namespace Mathematics::Matrix;
using namespace Utilities::String;

namespace Data::Integration
{
    class DataSet
    {
    public:
        DataSet(const std::string &file_path,
                const char &delimiter = ',',
                const bool &hasHeader = true,
                const bool &loadImmediately = true)
            : _file_path(file_path), _delimiter(delimiter), _hasHeader(hasHeader)
        {
            if (loadImmediately)
            {
                loadFile();
            }
        }

        DataSet(const Matrix<double> &m)
            : _m(m)
        {
        }

        void loadFile()
        {
            std::ifstream in(_file_path);
            if (in.fail())
                std::cout << "File " + _file_path + " not found." << '\n';

            bool headerParsed = false;

            int counter = 0;

            while (in.good())
            {
                std::vector<std::string> items = csv_read_row(in);

                if (!headerParsed && _hasHeader)
                {
                    _header_row = items;
                    headerParsed = true;
                }
                else
                {
                    _csv_contents[counter] = items;
                    counter += 1;
                }

                items.clear();
            }
            in.close();
        }

        void printHeaderValues() const
        {
            if (_hasHeader)
            {
                for (auto i : _header_row)
                {
                    std::cout << i << ' ';
                }
                std::cout << '\n';
            }
            else
            {
                std::cout << "File has no header." << '\n';
            }
        }

        void printColumnValues(const std::string &columnHeader) const
        {
            for (auto i : getColumnAsString(columnHeader))
            {
                std::cout << i << ' ';
            }

            std::cout << '\n';
        }
        /*
                    template <typename T>
                    T &sum()
                    {
                        T t{};
                        // Method 2: Using std::accumulate():
                        t = std::accumulate(v.begin(), v.end(), T{});
                        return t;
                    }
        */
        void printRowValues(const int row) const
        {
            for (auto i : getRow(row))
            {
                std::cout << i << ' ';
            }

            std::cout << '\n';
        }

        void printValue(const int row, const int col) const
        {
            std::cout << value(row, col) << '\n';
        }

        std::string value(const int row, const int col) const
        {
            std::string s{};

            try
            {
                s = _csv_contents.at(row).at(col);
            }
            catch (const std::out_of_range &e)
            {
                std::cerr << e.what() << '\n';
            }

            return s;
        }

        const std::vector<std::string> getRow(const int row) const
        {
            std::vector<std::string> ret;

            try
            {
                ret = _csv_contents.at(row);
            }
            catch (const std::out_of_range &e)
            {
                std::cerr << e.what() << '\n';
            }

            return ret;
        }

        /// Returns the number of rows in the training set.
        size_t getNumberOfRows() const
        {
            return _csv_contents.size();
        }

        /// Returns the number of rows in the training set.
        size_t getNumberOfColumns() const
        {
            return _header_row.size();
        }

        std::vector<std::string> getColumnAsString(const std::string &columnHeader) const
        {
            std::vector<std::string> ret;

            if (_hasHeader)
            {
                auto foundIt = std::find(_header_row.begin(), _header_row.end(), columnHeader);

                auto iColumn{-1};

                if (foundIt != _header_row.end())
                {
                    iColumn = foundIt - _header_row.begin();
                }

                if (iColumn != -1)
                {
                    for (auto const &[key, val] : _csv_contents)
                    {
                        ret.push_back(val[iColumn]);
                    }
                }
            }
            return ret;
        }

        std::vector<double> col(const std::string &columnHeader) const
        {
            return getColumnAsValue(columnHeader);
        }

        std::vector<double> getColumnAsValue(const std::string &columnHeader) const
        {
            std::vector<double> ret;

            if (_hasHeader)
            {
                auto foundIt = std::find(_header_row.begin(), _header_row.end(), columnHeader);

                auto iColumn{-1};

                if (foundIt != _header_row.end())
                {
                    iColumn = foundIt - _header_row.begin();
                }

                if (iColumn != -1)
                {
                    ret = getColumnAsValue(iColumn);
                }
            }
            return ret;
        }

        std::vector<double> getColumnAsValue(const size_t iColumn) const
        {
            std::vector<double> ret;

            for (auto const &[key, val] : _csv_contents)
            {

                std::string_view sv{val[iColumn]};

                const char *unparsed_str;

                try
                {
                    auto parsed_num{lexic_cast<double>(sv, &unparsed_str)};
                    ret.push_back(parsed_num);
                }
                catch (std::runtime_error &e)
                {
                    std::cout << "Bummer! " << e.what() << '\n';
                }
            }

            return ret;
        }

        std::pair<std::vector<double>, std::vector<double>> filterColumn(const size_t iColumn, const double threshold) const
        {
            std::vector<double> left, right;

            std::vector<double> values = getColumnAsValue(iColumn);

            for (auto const value : values)
            {
                if (value <= threshold)
                    left.push_back(value);
                else
                    right.push_back(value);
            }

            return std::make_pair(left, right);
        }

        Matrix<double> &toMatrix()
        {
            _m.resize(getNumberOfRows(), getNumberOfColumns());

            size_t row{}, col{};

            for (auto const &[key, val] : _csv_contents)
            {
                col = 0;

                for (auto &str : val)
                {
                    std::string_view sv{str};

                    const char *unparsed_str;

                    try
                    {
                        auto parsed_num{lexic_cast<double>(sv, &unparsed_str)};
                        _m.setValue(row, col, parsed_num);
                    }
                    catch (std::runtime_error &e)
                    {
                        std::cout << "Bummer! " << e.what() << '\n';
                    }

                    col++;
                }

                row++;
            }
            return _m;
        }

/*
        std::pair<DataSet, DataSet> splitAtRow(const size_t &row)
        {
            // std::pair<Matrix, Matrix> m = _m.splitAtRow(row);
            auto [x, y] = _m.splitAtRow(row);

            // creating the pair and working with it via reference saves copy in std::make_pair
            std::pair<DataSet, DataSet> result(DataSet{x}, DataSet{y});
            
            auto & dsX = result.first;
            auto & dsY = result.second;
 
            return result;
        }

        std::pair<DataSet, DataSet> splitAtColumn(const size_t &column)
        {
            return _m.splitAtColumn(column);
        }
*/

    private:
        std::vector<std::string> csv_read_row(std::istream &in)
        {
            std::stringstream ss;
            bool inquotes = false;
            std::vector<std::string> row; // relying on RVO
            while (in.good())
            {
                char c = in.get();
                if (!inquotes && c == '"') // beginquotechar
                {
                    inquotes = true;
                }
                else if (inquotes && c == '"') // quotechar
                {
                    if (in.peek() == '"') // 2 consecutive quotes resolve to 1
                    {
                        ss << (char)in.get();
                    }
                    else // endquotechar
                    {
                        inquotes = false;
                    }
                }
                else if (!inquotes && c == _delimiter) // end of field
                {
                    row.push_back(ss.str());
                    ss.str("");
                }
                else if (!inquotes && (c == '\r' || c == '\n'))
                {
                    if (in.peek() == '\n')
                    {
                        in.get();
                    }
                    row.push_back(ss.str());
                    return row;
                }
                else
                {
                    ss << c;
                }
            }
        }

    private:
        std::string _file_path{};
        char _delimiter{','};
        bool _hasHeader{true};

        std::string _file_contents{};
        std::map<int, std::vector<std::string>> _csv_contents{};
        std::vector<std::string> _header_row{};

        Matrix<double> _m{};
    };
}
