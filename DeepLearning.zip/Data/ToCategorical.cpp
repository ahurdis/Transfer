#include <iostream>
#include <vector>

#include "..\Mathematics\Matrix\Matrix.h"
using namespace Mathematics::Matrix;

Matrix<int> to_categorical(const std::vector<int> &labels, size_t num_classes)
{
    // Create a matrix of size (number of samples, num_classes)
    size_t num_samples = labels.size();

    Matrix<int> categorical{num_samples, num_classes};

    // For each sample, set the value in the corresponding column to 1
    for (size_t i = 0; i < num_samples; ++i)
    {
        int label = labels[i];
        categorical.setValue(i, label, 1);
    }

    return categorical;
}

Matrix<double> to_categorical(const Matrix<double> &m, size_t num_classes)
{
    // Create a matrix of size (number of samples, num_classes)
    size_t num_samples = m.rows();

    Matrix<double> categorical{num_samples, num_classes};

    // For each sample, set the value in the corresponding column to 1
    for (size_t i = 0; i < num_samples; ++i)
    {
        size_t label = static_cast<size_t>(m.getValue(i, 0));
        categorical.setValue(i, label, 1.0);
    }

    return categorical;
}

int main()
{
    const size_t num_classes {4};

    std::vector<int> labels = {0, 1, 2, 3, 2, 1, 3};

    Matrix<double> categorical = to_categorical(labels, num_classes);

    std::cout << categorical;

    return 0;
}
